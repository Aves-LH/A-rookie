?package(someplayer):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="someplayer" command="/usr/bin/someplayer"
