#
# Regular cron jobs for the someplayer package
#
0 4	* * *	root	someplayer_maintenance
