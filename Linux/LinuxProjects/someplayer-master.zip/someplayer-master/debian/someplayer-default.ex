# Defaults for someplayer initscript
# sourced by /etc/init.d/someplayer
# installed at /etc/default/someplayer by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
