/*
 * SomePlayer - An alternate music player for Maemo 5
 * Copyright (C) 2010 Nikolay (somebody) Tischenko <niktischenko@gmail.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef TOOLSWIDGET_H
#define TOOLSWIDGET_H

#include <QWidget>

namespace Ui {
	class ToolsWidget;
}

class ToolsWidget : public QWidget
{
	Q_OBJECT

public:
	explicit ToolsWidget(QWidget *parent = 0);
	~ToolsWidget();
	void reset();
	void setFocus();

public slots:
	void updateIcons();
	void show();
	void toggleArrows(bool);
	void hideFSButton();
	void setFullscreenState(bool);

signals:
	void toggleFullscreen(bool);
	void search(QString);
	void nextSearch();
	void prevSearch();

private:
	Ui::ToolsWidget *ui;
	bool _fullscreen;
	QString _icons_theme;

private slots:
	void _fullscreen_button();
};

#endif // TOOLSWIDGET_H
