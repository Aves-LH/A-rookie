# qt-mplayer

qt编写视频播放器。调用mplayer进行视频和音频的播放。支持多种视频和音频格式。

操作平台：Linux。

![](https://github.com/TonySudo/qt-mplayer/blob/master/mplayer.png)
