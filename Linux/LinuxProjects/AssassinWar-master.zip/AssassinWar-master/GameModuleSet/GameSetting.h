#pragma once
class GameSetting
{
public:
    GameSetting(void);
    ~GameSetting(void);
};

