#include "GameSetting.h"


GameSetting::GameSetting(void)
{
}


GameSetting::~GameSetting(void)
{
}
