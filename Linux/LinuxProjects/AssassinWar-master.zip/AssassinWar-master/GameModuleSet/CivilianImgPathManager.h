#pragma once

class CivilianImgPathManager
{
public:

    static const char* getRandomCivilianImgPathBegin();

private:
    CivilianImgPathManager(void);
    ~CivilianImgPathManager(void);
};

