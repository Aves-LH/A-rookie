#ifdef _DEBUG
#pragma comment(lib,"QtUiToolsd.lib")
#pragma comment(lib,"MapLoaderd.lib")
#pragma comment(lib,"GameModuleSetd.lib")
#else
#pragma comment(lib,"QtUiTools.lib")
#pragma comment(lib,"MapLoader.lib")
#pragma comment(lib,"GameModuleSet.lib")
#endif // _DEBUG