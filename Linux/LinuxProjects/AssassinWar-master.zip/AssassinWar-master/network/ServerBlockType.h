#pragma once
const unsigned char  UPDATA_CHARACTER = '1';
const unsigned char  UPDATA_COMBAT = '2';
const unsigned char  UPDATA_GAME_INFO = '3';
const unsigned char UPDATE_CURRENT_MAP = '4';

const unsigned char ADD_PLAYER = '5';
const unsigned char ADD_NPC = '6';

const unsigned char SET_PLAYER_POSITION = '7';
const unsigned char JOIN_REQUEST = '8';