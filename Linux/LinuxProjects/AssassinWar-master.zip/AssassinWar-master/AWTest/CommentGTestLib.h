#ifdef _DEBUG
#pragma comment(lib,"gtestd.lib")
#pragma comment(lib,"gtest_main-mdd.lib")
#else
#pragma comment(lib,"gtest.lib")
#pragma comment(lib,"gtest_main-md.lib")
#endif // _DEBUG